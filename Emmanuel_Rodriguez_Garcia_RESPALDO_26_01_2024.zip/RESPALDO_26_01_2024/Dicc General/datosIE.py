import json
from time import time
import os
import sys
import zipfile
import math

class datos:
	def __init__(self,db):
		self._tI = time()
		self._db = db
		self._tot = 0
	def _crColl(cc,_n,_idx):
		_cTmp = cc._db.create_collection(_n)
		for _i in _idx:
			_cTmp.create_index([(_i["cam"],_i["tip"])])
		return _colTmp
	def importar(i,n,_g):
		[i._db[_g.coll].create_index([_ix]) for _ix in [("cercanos.dist",1),("cercanos.id_c",1),("properties.grupo",1),("properties.visible",1),("geometry","2dsphere")]]
		_a,j,id=open(n,"r"),json.load(_a),1
		i._tot = len(j["features"])
		for f in j["features"]:
			f["_id"]=id
			i._db[_g.coll].insert_one(f)
			id+=1
			_porc = round((float(id)/float(i._tot))*100.0,1)
			if _g._proceso(str(_porc)+"% , ",True if _porc in _g.porc else False,_porc)>0:
				_g.porc.remove(_porc)
		_g.logs.seek(-2,os.SEEK_END)
		_g._proceso("</span><br>")
		return id,_g._arr(15)
	def exportar(e,n,_g):
		arch,_tmp_ = open(n.replace(".","_Generalizado."),"w"),open(n.replace(".","_Tmp."),"w")
		arch.write('{"type": "FeatureCollection","name": "datosJSON","crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:EPSG::4326" } },"features": [\n')
		_tmp_.write('{"type": "FeatureCollection","name": "datosTMP","crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:EPSG::4326" } },"features": [\n')
		tmp=""
		for o in e._db[_g.coll].find({},{"cercanos":0}):
			tmp=json.dumps(o)
			arch.write(tmp)
			arch.write(",\n")
			if o['properties']['visible']==True:
				_tmp_.write(tmp)
				_tmp_.write(",\n")
			_porc = round((float(o['_id'])/float(e._tot))*100.0,1)
			if _g._proceso(str(_porc)+"% , ",True if _porc in _g.porc else False,_porc)>0:
				_g.porc.remove(_porc)
		_g.logs.seek(-2,os.SEEK_END)
		_g._proceso("</span><br>")
			
		arch.seek(-3, os.SEEK_END)
		arch.write("\n]}")
		arch.close()
		_tmp_.seek(-3, os.SEEK_END)
		_tmp_.write("\n]}")
		_tmp_.close()
		compression = zipfile.ZIP_DEFLATED
		zipObj = zipfile.ZipFile(n.replace(".","_Generalizado.")+".zip", 'w')
		zipObj.write(n.replace(".","_Generalizado."),compress_type=compression)
		zipObj.close()
	def resumen(r,_g):
		_nV = r._db[_g.coll].find({"properties.visible":False}).count()
		return [r._tot,_nV,(float(_nV)/float(r._tot))*100.0,"%"] 
	def _extend(_e,_g):
		_ext_ = list(_e._db[_g.coll].aggregate([{"$unwind":"$geometry.coordinates"},{"$group":{"_id": "$_id","lat":{"$first":"$geometry.coordinates"},"lon":{"$last":"$geometry.coordinates"}}},{"$group":{"_id":None,"maxLat":{"$max":"$lat"},"minLon":{"$min":"$lon"},"minLat":{"$min":"$lat"},"maxLon":{"$max":"$lon"}}}]))[0]
		return [[_ext_['maxLat'],_ext_['minLon']],[_ext_['minLat'],_ext_['maxLon']]]
	def importarLine(i,n,_g):
		[i._db[_g.coll].create_index([_ix]) for _ix in [("cercanos.dist",1),("cercanos.id_c",1),("properties.grupo",1),("properties.visible",1),("geometry","2dsphere")]]
		_a,j=open(n,"r"),json.load(_a)
		i._tot = len(j["features"])
		for f in j["features"]:
			f["_id"]=id
			i._db[_g.coll].insert_one(f)
			id+=1
			_porc = round((float(id)/float(i._tot))*100.0,1)
			if _g._proceso(str(_porc)+"% , ",True if _porc in _g.porc else False,_porc)>0:
				_g.porc.remove(_porc)
		_g.logs.seek(-2,os.SEEK_END)
		_g._proceso("</span><br>")
		return id,_g._arr(15)