import os,sys,json,datetime
import numpy as np
from arcpy import env as e
from arcpy import da
from arcpy import analysis as an, management as man
from arcpy import FeatureVerticesToPoints_management as fV
from arcpy import MakeFeatureLayer_management as mF
from arcpy import SelectLayerByAttribute_management as sA
from arcpy import CopyFeatures_management  as cpy
from arcpy import Array,Polygon,Point
import pandas as pan
from datetime import datetime as dt
import re


class GeneralizarCosta:
    def __init__(self,gdb,fet,dist,sal):
        self._gdb = gdb
        self._fet = fet
        self._dist = int(dist)
        self._distP = int(dist)*-1
        self._sal = sal
        self._eliminar = []
        
    def cargarDatos(self):
        e.workspace = self._gdb
        e.overwriteOutput = True
        with da.SearchCursor(self._fet,["OID@","SHAPE@JSON"]) as rows:
            return [row for row in rows]
    def buff(self):
        vtxs =[]
        def fueraRango(v):
            if (v[4]/self._distP) > 0.85 and (v[4]/self._distP) < 1.15:
                resp.append({"lin":lin,"coord":[tuple(v[1])]})
                return True
            return False
        def rango(n):
            return True if n/self._distP > 0.5 and n/self._distP <1.15 else False

        temp = ['buffer','verticesBff','vertices','copyCosta']
        man.Delete(temp)
        cpy(self._fet,temp[3])
        print(self._fet, temp[0],self._distP)
        an.Buffer(self._fet, temp[0],self._dist)
        fV(temp[0],temp[1])
        fV(self._fet,temp[2])
        an.Near(temp[2],temp[1],"%s Meters" % str(self._distP + self._distP/2),"LOCATION","ANGLE","PLANAR")
        resp,lin = [{"lin":0,"coord":[]}],0
        with da.SearchCursor(temp[2],"*") as cur:
            vtxs = cur._as_narray()
            ban,lin = (True,1)  if vtxs[0][4] > -1 else (False,0)
            ult = False if ban else True
            ciclo = list(range(len(vtxs)-1))
            for i in ciclo: 
                if ban:
                    if vtxs[i-1][4]==-1 or vtxs[i+1][4]==-1:
                        if rango(vtxs[i][4]):
                            resp.append({"lin":lin,"coord":[tuple(vtxs[i][1])]})
                            ban=False
                        else:
                            for x in range(2,10):
                                if fueraRango(vtxs[i-x]):
                                    ban = False
                                    ciclo.remove(i-x)
                                    break
                                ciclo.remove(i-x)
                    else:   
                        self._eliminar.append(Point(vtxs[i][1][0],vtxs[i][1][1]))
                else:
                    if vtxs[0][1] not in vtxs[i+1][1]:
                        if i < len(vtxs) and vtxs[i+1][4]>-1:
                            if rango(vtxs[i+1][4]):
                                resp[lin]["coord"].append(tuple(vtxs[i+1][1]))
                                lin+=1
                                ban = True
                                ciclo.remove(i+1)

            if ult:
                resp[0]["coord"].append(resp[lin]["coord"][0])
                resp.pop()
                resp.pop()   
        with da.UpdateCursor(temp[3],'SHAPE@') as cur:
            for pol in cur:
                pol[0] = Polygon(Array(self._eliminar))
                cur.updateRow(pol)

        myJson = {"type":"FeatureCollection","crs":{"type":"name","properties":{"name":"EPSG:6372"}}, "features":[]}
        for x in resp:
            myFeat = {"type":"Feature","geometry":{"type":"Linestring","coordinates":x["coord"]},"properties":{"id":x["lin"],"desc":"Alguna descripcion del porque esta linea"}}
            myJson["features"].append(myFeat)
        texto = json.dumps(myJson)
        a = open("%s.geojson" % self._sal,"w")
        a.write(texto)
        a.close()

_prm = "GeneralizaLineaCosta D:/misDocs/2023/GENERALIZACION/GITHUB/sistema-colaborativo-de-generalizacion/pruebas.gdb costa -90 resultado_%s" % re.sub("[:. -]","",str(dt.today()))
_arg = _prm.split(" ")
#_arg = "GeneralizaLineaCosta C:/Users/iscem/Documents/pruebas.gdb costa -90 salida".split(" ") #sys.argv
g = GeneralizarCosta(_arg[1],_arg[2],_arg[3],_arg[4])
_g =g.cargarDatos()[0]
g.buff()

