import socket
import socks
import keyboard as k

from variables import Variables

def create_proxy_server():
    _v = Variables()
    # Crea un socket para el servidor proxy
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("172.23.32.1",8000))
    server_socket.listen(1)
    while True:
        _prx = _v.ipsProxi(30).split(":")
        # Espera a que llegue una conexión
        print("Crea un socket para el servidor final ",_prx )
        client_socket, client_address = server_socket.accept()
        print(client_socket,client_address)


        #client_socket.send(f"index.html".encode())
       


        socks_socket = socks.socksocket()
        socks_socket.set_proxy(socks.SOCKS5, _prx[0],int(_prx[1]))
        client_socket.send(socks_socket.connect(('www.facebook.com', 80)))
        
        # Envía la petición del cliente al servidor final
        petCli = client_socket.recv(4096)
        print(petCli)
        socks_socket.sendall(petCli)
        client_socket.sendall(socks_socket.recv(4096))
        try:
            if k.is_pressed('s'):
                print("A la burguer")
                client_socket.close()
                socks_socket.close()
                break
        except:
            client_socket.close()
            socks_socket.close()
            break
if __name__ == '__main__':
    create_proxy_server()