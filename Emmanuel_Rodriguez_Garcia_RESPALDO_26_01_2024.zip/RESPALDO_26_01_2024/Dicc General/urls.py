from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('<int:palabra_id>/', views.detail, name='detail'),
    # ex: /dicc/5/results/
    path('<int:palabra_id>/results/', views.results, name='results'),
    # ex: /polls/5/vote/
    path('<int:palabra_id>/vote/', views.vote, name='vote'),
    path('datBD', views.datBD, name='datBD'),
    path('ejecutar/', views.ejecutar, name='ejecutar'),
    path('descargar/<str:url_result>/', views.descargar, name='descargar'),
    path('descargar/ZIPs/<str:_nom>/<str:_zip>/', views.descargar, name='descargar'),
    path('upFile', views.upFile, name='upFile'),
    path('servSkeletor/<int:tipo>/<str:ruta>', views.servSkeletor, name='servSkeletor'),

]