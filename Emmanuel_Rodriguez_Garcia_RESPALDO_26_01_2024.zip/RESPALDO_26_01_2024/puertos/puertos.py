from clases import Convertir

import json,sys
import shapefile

from arcpy import env as e
from arcpy import management as man
from arcpy.management import CreateFeatureDataset,Delete
from arcpy import Array,Point
from arcpy.da import SearchCursor as sc,InsertCursor as iC,UpdateCursor as uC
import pathlib as ph



def enum(v):
    return v+1


a = [sc,e]
ws = "%s\\datos\\puertos.gdb\\" % str(ph.Path.cwd())
e.workspace = ws
e.overwriteOutput = True
_vertex,_shpTmp,_poli,_centraLine,_pol_den,punto_ini = "datos/result/_vtx_","datos/result/cen_tmp.shp","datos/%s.shp" % sys.argv[1],"datos/result/centraLine.shp","datos/poligonosDensificado.shp","datos/punto_inicio.shp"
clss =  Convertir(_poli)
_vtx_ = clss.densificar(_pol_den)
sh = shapefile.Writer(_vertex,1,True)
sh.field("ID","C")
for p in _vtx_:
    sh.record(sh.point(*p))
sh.close()




clss.setNom(_pol_den)
try:
    Delete("Topos")
except:
    print("[%s] No existe Dataset, se creará uno nuevo..." % clss.hora(),end=" -> ")
CreateFeatureDataset(ws,"Topos",spatial_reference=clss._nom)
print("[%s] Ejecutando Skeletor..." % clss.hora(),end=" -> ")
import polyskel
datos = [clss.SkeletorFet(json.loads(row[1])["rings"]) for row in sc(clss._nom,["OID@","SHAPE@JSON"])]
print(len(datos))
print("[%s] Obteniendo Linea Central..." % clss.hora())
clss.centraLine(datos,_shpTmp,man,_centraLine,e,_vertex,uC,sc,punto_ini)








# print("[%s] Calculando conexiones iniciales y finales..." % clss.hora())
# _ids = [n[0] for n in [t for t in sc("TablaNear",["IN_FID","NEAR_DIST"],sql_clause=("DISTINCT IN_FID","ORDER BY NEAR_DIST DESC"))] if n[1]==0]
# _ids.sort()
# _wh = "%d," * len(_ids) % tuple(_ids)
# where = "FID IN (%s)" % _wh[:-1]
# print(where)
# man.SelectLayerByAttribute(_centraLine,"CLEAR_SELECTION")
# man.MakeFeatureLayer(_centraLine,"final")
# man.SelectLayerByAttribute("final","NEW_SELECTION",where)
# man.DeleteFeatures("final")

# fin = sc("final","*")
# print(list(fin))






    # for gg in list(set([g[0] for g in _tb])):
    #     gpo[gg]=[]
    # _tb.reset()
    
    # _vec = list(set([_agr(x) for x in _tb if x[1] not in ya]))
    
    # for z in _vec:
    #     with sc("final",["FID","SHAPE@LENGTH"],where_clause= "FID IN (%d,%d,%d)" % (z,gpo[z][0],gpo[z][1])) as c:
    #         e=list(c)
    #         e.sort(key=myFunc)
    #         _del+=e[:2]
    # _e = [_d[0] for _d in _del]
    # _wer = "%d,"*len(_e) % tuple(_e)
    # print(_wer)
    # man.SelectLayerByAttribute("final","NEW_SELECTION","FID IN (%s)" % _wer[:-1])
    # man.DeleteFeatures("final")


        
