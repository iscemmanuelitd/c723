import json
import os
import pathlib as ph
from unidecode import unidecode as unidec
import psycopg2
from time import time
#import socket



class diccionario:
    def __init__(self,_ent):
        self.datos = [ph.WindowsPath(os.path._getfullpathname(_ar))  for _ar in [_ent,"dicc/dict_rae_txt/dics","dicc/Diccionario2023.json","dicc/Inconsistencias.json"]]
    def _cF(ins,_a,_e):				
        #_dec = requests.get(_a, {} ).text
        _dec = open(os.path._getfullpathname(_a),"r")
        # _key,i,_obj=map(ord,_e)*100,0,""	
        # for l in _dec.readlines().split(",")[:-1]:
        #     _obj+=chr(int(l)-_key[i])
        #     i+=1
        j=json.loads(_dec.read())
        return  j[_e]
    def _getCx(ins,_cf,_ec):
        _prm=ins._cF(_cf,_ec)
        _cn=psycopg2.connect(**_prm)
        return _cn.cursor()
    def _tiempo(_s,_ini):
        return "%.2f seg"  % (time() - _ini)
    def _remplazar(_s,_cad):
        return  _cad.replace("(","").replace(")","").replace("[","").replace("]","").replace(",","").replace("'","-").replace('"',"-").split(" ")
    def _getEntDB(_s,_p,_sql="SELECT id,nombre FROM continuo_topo50_1968_2018.ed_localidades_rasgos_urbanos_p WHERE nombre<>'Ninguno'",ban=True):
        _i,_conn = time(), _s._getCx(_p[0],_p[1])
        _conn.execute(_sql)
        _obj = {"datos":[]}
        if ban:
            for _rec in _conn.fetchall():
                _obj["datos"].append({"id":_rec[0],"valor":_rec[1],"norm":unidec(_rec[1].lower())})
            with _s.datos[0].open("w",1024,"utf-8") as _f:
                _f.write(json.dumps(_obj))
                _f.close()
        else:
            for _rec in _conn.fetchall():
                _obj["datos"].append(_rec)
        print(_s._tiempo(_i))
        return len(_obj["datos"]) if ban else _obj["datos"]
    def crearDiccionario(_s):
        _i, dicJson, cont, _abc  = time(), {} , 0, ["ñ"]
        [_abc.append(chr(l)) for l in range(97,123)]
        for _l in  _abc:
            dicTemp , dicJson[_l] =  [], []
            _arch = _s.datos[1] / "{}.txt".format(_l)
            with _arch.open("r",1024,"utf-8") as _file:
                for _line in _file:
                    try:
                        _p=_line.strip().split(",") 
                        _pc = _p[0][0:-1] if _p[0][-1].isnumeric() else _p[0]
                        dicTemp.append(_pc)
                        if len(_p)==2:
                            dicTemp.append(_pc[:-1*len(_p[1].strip())]+_p[1].strip())
                        cont +=  len(_p)
                    except Exception as e:
                        print(_line,e)
                [dicJson[_l].append(x) for x in dicTemp if x not in dicJson[_l]]
            _file.close()
            with _s.datos[2].open("w",1024,"utf-8") as _f:
                _f.write(dicJson.__str__().replace("'",'"'))
            _f.close()
        print("[info] Diccionario Actualizado. %d palabras...  %s" % (cont, _s._tiempo(_i)))
        return cont
    def _vuelta2(_s,_v_,_d_):
        return _v_ if (_v_.lower() not in _d_ ) and (_v_ not in _d_) else None
    def revisar(_s):
        _in,objRev = time(), {}
        with _s.datos[0].open("r",1024,"utf-8") as _fR:
            objRev = json.loads(_fR.read())
        __dicc = {}
        with _s.datos[2].open("r",1024,"utf-8") as _f:
            __dicc = json.loads(_f.read().__str__())
        _d,_res, _cntR = objRev["datos"],{"datos":[]},0
        for _i in range(len(_d)):
            _v , _n = _s._remplazar(_d[_i]["valor"]), _s._remplazar(_d[_i]["norm"])
            _err = [_s._vuelta2(_v[_i],__dicc[ _n[_i][0]])  for _i in range(len(_n)) if _n[_i][0].isalpha() and _n[_i] not in __dicc[ _n[_i][0]]]
            if len(_err)>0:
                if len(_err)==1 and _err[0] is not None:
                    _d[_i]["norm"] = _err
                    _res["datos"].append(_d[_i])
                    _cntR+=len(_err)
        print("[info] %d palabras que NO se encuentran en el diccionario...  %s"  % (_cntR,_s._tiempo(_in)))
        return _res
    def exportar(_s,_sal):
        with _s.datos[3].open("w",1024,"utf-8") as _f_:
            _f_.write(_sal.__str__().replace("', '",'", "').replace("': '",'": "')
            .replace("':",'":').replace("['",'["').replace("']",'"]').replace("{'",'{"').replace(", '",', "').replace("'","-")     ) #.replace("'",'"')
            return len(_sal["datos"])
           

    

# class sockete:
#     def __init__(self,_h,_p):
#         self._host = _h
#         self._port = _p
#     def servidor(_s):
#         with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
#             s.bind((_s._host,_s._port))
#             print("Esperando coneccion con el Cliente...")
#             s.listen(1)
#             conn, addr = s.accept()
#             with conn:
#                 print('Connected by', addr)
#                 #while True:
#                 conn.sendall('HOLA')
#                 data = conn.recv(1024)
#                 print(unidec(str(data)))
#                     # if not data: break
#                     # conn.sendall(data)

