import json
import tqdm
import os
import sys
import numpy
import socket	
from pymongo import MongoClient
from datetime import datetime as dt
from shapely import geometry, ops
from time import time
import zlib, json, base64

class BD:
    def __init__(self,_h,_p,_db):
        self.host,self.port,self.database,self.conn=_h,_p,_db,MongoClient(_h,_p)[_db]
    def _getCnn(c):
        return c.conn
    def _getColl(s,_c,_cnx):
        _lst = [c for c in _cnx.list_collection_names() if _c==c]
        return _cnx.get_collection(_c) if len(_lst)==1 else None
	def _dropColl(d,_usu,_cnx):
		[_cnx[co].drop() for co in _cnx.list_collection_names() if co[16:]==_usu]
    def _createColl(s,_nom,_cnx):
        return _cnx.create_collection(_nom)
    def _crIdx(s,_c,_idx,_val):
        _c.create_index(name=_idx, keys=[_val])   
    def _exist_(e,_ob,_ky):
        return False if len([i[0] for i in _ob.items() if i[0]==_ky])==0 else True
    def _getDoc(d,_c,_e,_d):
        _dc = _c.find_one(filter={"_id":_e})
        if _dc is None:
            _c.insert_one({"_id":_e,"datos":{_d:{"fecha":dt.now()}}})
            return  _c.find_one(filter={"_id":_e})
        return _c.update_one({"_id":_e},{"$set":{"datos."+_d:{"fecha":dt.now()}}}) if not d._exist_(_dc["datos"],_d)  else _dc 
    def _setD(s,_c,_e):
        _po = s._getColl("ent_fed_3",s._getCnn()).find_one({"properties.Cve_Ent":_e},{"_id":0,"coord":{"$arrayElemAt":["$geometry.coordinates",0]}})
        _geoms = [{"geometry":{"$geoIntersects":{"$geometry":{"type":"Polygon","coordinates":[i]}}}} for i in _po['coord'] if len(i)>3]
        for _ln in s._getColl('red_vial_Mexico',s._getCnn()).find({"$or":_geoms}):
            _c.insert_one(_ln)
    def _valGeo(v,_coo):
        try:
            x = geometry.LineString(_coo)
            return _coo
        except Exception as e:
            vec=[]
            [[vec.append(_xy) for _xy in _c] for _c in _coo]
            return vec
    def json_zip(z,j):
        return {'zip': base64.b64encode(zlib.compress(json.dumps(j).encode('utf-8'))).decode('ascii')}
    def json_unzip(u,jz):
        return json.loads(zlib.decompress(base64.b64decode(jz['zip'])))                

class sock:
    def __init__(self,_ip,_port):
        self.ip=_ip
        self.port=_port
    def _cnSckServ(s,_c):
        _s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        _s.bind((s.ip,s.port))
        _s.listen(_c)
        return _s
    def _envClient(e,_fn,_c):
        SEPARATOR="<SEPARATOR>"
        BUFFER_SIZE = 2048
        filesize = os.path.getsize(_fn)
        _c.send(f"{_fn}{SEPARATOR}{filesize}".encode())
        progress = tqdm.tqdm(range(filesize), "Enviando Resultado %s" % _fn, unit="B", unit_scale=True, unit_divisor=1024)
        with open(_fn, "rb") as f:
            while True:
                bytes_read = f.read(BUFFER_SIZE)
                if not bytes_read:
                    break
                _c.sendall(bytes_read)
                progress.update(len(bytes_read))
    
