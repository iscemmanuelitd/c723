import datetime
from django.db import models
from django.utils import timezone




class Svg(models.Model):
    codigo_svg = models.TextField()
    status = models.BooleanField(True)
    def __str__(self):
        return self.codigo_svg
    def activos(self):
        return self.codigo_svg if self.status is True else None





class Palabra(models.Model):
    palabra_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('fecha')
    def __str__(self):
        return self.palabra_text
    def was_published_recently(self):
        return self.pub_date >= timezone.now() - datetime.timedelta(days=1)


class Choice(models.Model):
    palabra = models.ForeignKey(Palabra, on_delete=models.CASCADE)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)
    def __str__(self):
        return self.choice_text

