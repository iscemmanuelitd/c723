from django.http import HttpResponse,JsonResponse
from django.template import loader
from django.views.decorators.csrf import csrf_exempt
from .models import Palabra
from .diccLib import diccionario as dicc
import json,os,datetime
import pathlib as ph
from django.shortcuts import render
import zipfile as zip

_d = datetime.datetime.now()
d = dicc("dicc/subido%s.json" % _d.strftime("%x").replace("/","_"))
_resp =  {"Revisar":0,"Diccionario":0,"Inconsistencias":0}


def escribe(txt):
        _res = open("dicc/_res.log","a")
        _res.write("[info] %s.\n" % txt)
        _res.close()


def index(request):
    latest_palabra_list = Palabra.objects.order_by('-pub_date')[:5]
    template = loader.get_template('dicc/index.html')
    context = {'latest_palabra_list': latest_palabra_list,}
    return HttpResponse(template.render(context, request))

def detail(request, palabra_id):
    return JsonResponse({"nom":"Estas buscando la palabra %s." % palabra_id})

def results(request, palabra_id):
    response = "You're looking at the results of question %s."
    return HttpResponse(response % palabra_id)

def vote(request, palabra_id):
    return HttpResponse("You're voting on question %s." % palabra_id)


def ejecutar(request):
    _res = open("dicc/_res.log","w")
    _res.close()
    escribe("Creando o Actualizando diccionario de datos")
    _resp["Diccionario"] = d.crearDiccionario()
    escribe("Comenzó la revisión...")
    _resp["Inconsistencias"] = d.exportar(d.revisar())
    escribe("Finalizando proceso")
    _re = json.dumps(_resp)
    wfile = open("dicc/salida.json","w")
    wfile.write('%s' % _re)
    return JsonResponse(_resp)

def descargar(request,url_result=None,_nom=None,_zip=None):
    _arch = ph.WindowsPath(os.path._getfullpathname("dicc/%s" % url_result if _zip is None else "ZIPs/%s/%s" %(_nom,_zip)))
    if _zip is None:
        with _arch.open("r",-1,"utf-8") as _file:
            datos = json.load(_file)
            return JsonResponse(datos)
    else:
        with _arch.open("rb",-1) as zz:
            response = HttpResponse(zz.read(), content_type="application/zip")
            response['Content-Disposition'] = 'inline; filename=' + os.path.basename(_zip+".zip")
            return response

@csrf_exempt    
def datBD(request):
    dat = request.POST
    escribe("Obteniendo palabras a revisar desde la BD")
    _resp["Revisar"] = d._getEntDB(["dicc/dbs.ini","_psq_"],dat['sql'],False)
    return JsonResponse({"success":True,"revisar":_resp["Revisar"]})


@csrf_exempt
def upFile(request):
    f = request.FILES['filetoupload']
    with open("dicc/TMP_%s" % f.name, 'wb') as x:
        x.write(f.read())
        if f.name.split(".")[1]=="zip":
            _f ="%s" % f.name.split(".")[0]
            with zip.ZipFile("dicc/TMP_%s" % f.name,"r") as zr:
                zr.extractall("ZIPs/%s" % f.name.split(".")[0])
        else: 
            _f = "TMP_%s" % f.name
    return JsonResponse({"success":True,"revisar":666,"file":_f})
   


from Skeletor.clases import Convertir as conv
def servSkeletor(request,tipo,ruta):
    _shp_ = conv("ZIPs/%s/%s.shp" % (ruta,ruta),3500)
    if tipo>0:
        _polSimp=_shp_.simpliPoly(tipo)
        _shp_.setNom(_shp_.crearShp(_polSimp,'Polygon',"-simpli_%s" % tipo))
    _linSkele = _shp_.Skeletor(_shp_.getNom())
    _ruta = _shp_.crearShp([{'type':'LineString','coordinates':_l} for _l in _linSkele] ,'LineString',"-Skeletor")
    res = {"success":True,"Lineas: ":len(_linSkele),"file":_ruta.split(".")[0]}
    compression = zip.ZIP_DEFLATED
    zf = zip.ZipFile("%s.zip" % res['file'],'w')
    for _e in ["shp","shx","dbf","prj"]:
        zf.write(res['file']+"."+_e,compress_type=compression)
    zf.close()
    return JsonResponse(res)