from clases import BD, sock
from datetime import datetime as dt
from shapely import geometry, ops
from time import time
import json 

class DIST:
    def __init__(self,_i):
        self.ip,self.dist,self.ent,self.usa,self.falt,self.sck=_i,0,0,[],[],None
    def _setSck(ss,_s):
        ss.sck = _s
    def _getSck(gs):
        return gs.sck
def _dist_(_n,_i,_myC):
    def _newU(_a):
        for _e in range(4):
            if _a[_e] in _a[_e+1:]:
                _v =_a[_e]
                _a.remove(_v)
                _a.remove(_v)
                return _a
    def _act(_w_):
        _geo.append(_BD._valGeo(_w_["geometry"]["coordinates"]))
        _L =[_p["LONGITUD"],_w_["properties"]["LONGITUD"]]
        _iAc = [_i,_w_['properties']['ID_RED']] if _L[0]>_L[1] else [_w_['properties']['ID_RED'],_i]
        _wU = _newU([_p["UNION_INI"],_p["UNION_FIN"],_w_["properties"]["UNION_INI"],_w_["properties"]["UNION_FIN"]])
        _newG = ops.linemerge(geometry.MultiLineString(_geo))
        _myC.update_one({"properties.ID_RED":_iAc[0]},{"$set":{"geometry":_newG.__geo_interface__,"properties.LONGITUD":sum(_L),"properties.UNION_INI":_wU[0],"properties.UNION_FIN":_wU[1]}})
        _myC.delete_one({"properties.ID_RED":_iAc[1]})
        _iDst.usa.append(_iAc[1])
        _iDst.falt.append(_i)
        if _iAc[0] not in _iDst.falt:
            _iDst.usa.append(_iAc[0])
        return _iAc
    _p = _n["properties"]
    _geo = [_BD._valGeo(_n["geometry"]["coordinates"])]
    _if = [list(_myC.find({"$and":[{"properties.ID_RED":{"$ne":_i}},{"$or":[{"properties.UNION_INI":_p[_u_]},{"properties.UNION_FIN":_p[_u_]}]}]})) for _u_ in ["UNION_INI","UNION_FIN"]]
    if len(_if[0])!=1 and len(_if[1])!=1:
        _iDst.usa.append(_i)
        return
    if len(_if[0])==1 and len(_if[1])==1:
        return _act(_if[0][0] if _if[0][0]["properties"]["LONGITUD"]>_if[1][0]["properties"]["LONGITUD"] else _if[1][0])
    return _act(_if[0][0] if len(_if[0])==1 else _if[1][0])

_iDst = DIST("127.0.0.1")
iSck = sock(_iDst.ip,12345)
_iDst._setSck(iSck._cnSckServ(10))

while True:
    print("Socket Escuchando.....")
    _cli,addr = _iDst.sck.accept()
    _iDst.usa = []
    print ('Cliente conectado con ip: ', addr )
    _cli.send('GENERALIZACION DE UNION DE LINEAS DE LA RED_VIAL - RNC'.encode())
    ent,dist,_gJson=int(_cli.recv(1024).decode()),_cli.recv(1024).decode(),addr[0]+"_"+dt.now().strftime("%d%m%Y-%H%M%S_")
    _BD = BD("localhost",27017,"generalizacion")
    _cnx = _BD._getCnn()
    _hist = _BD._getColl('red_vial',_cnx)
    _tmp = _hist.find({"_id":ent,"datos.%sm" % dist:{"$exists":True}})
    _dat=None
    _tm = time()
    if _tmp.count()==0:        
        _cli.send("True".encode())
        [_BD._getColl(c,_cnx).drop() for c in _cnx.list_collection_names() if c.split("_")[0]==addr[0]]
        _cli.send("[info] Obteniendo datos de la entidad".encode('utf8'))
        _myColl = _BD._createColl(_gJson,_cnx)
        [_BD._crIdx(_myColl,"_idx_"+_i[0][-6:],_i) for _i in [("properties.UNION_INI",1),("properties.UNION_FIN",1),("properties.ID_RED",1)]]
        _BD._setD(_myColl,ent)
        _tmG,_hra = time(),"[%s] Generalizando Lineas" % dt.now().strftime("%d-%m-%Y %H:%M:%S")
        _cli.send(_hra.encode())
        while True:
            _cant,_iDst.falt = _myColl.count_documents({"properties.LONGITUD":{"$lt":float(dist)},"properties.ID_RED":{"$nin":_iDst.usa}}),[]
            _red =list(_myColl.find({"properties.LONGITUD":{"$lt":float(dist)},"properties.ID_RED":{"$nin":_iDst.usa}}).sort("properties.ID_RED",1))
            if _cant==0:
                break
            for pos in range(_cant):
                if _red[pos]['properties']['ID_RED'] not in _iDst.usa:
                    _dist_(_red[pos],_red[pos]['properties']['ID_RED'],_myColl)
        _t_ = "[%s] Tiempo de Generalizacion: %.10f seg." % (dt.now().strftime("%d-%m-%Y %H:%M:%S"),(time()-_tmG))
        _cli.send(_t_.encode())
        _dat = {"line":list(_myColl.find({}))}
        _hist.update_one({"_id":ent},{"$set":{"datos.%sm" % dist:_BD.json_zip(_dat),"cantRes":_myColl.count_documents({})}}) 
    else:
        _cli.send("False".encode())
        _dat = _BD.json_unzip(list(_tmp)[0]['datos'][dist+"m"]) 
    _arc = open(_gJson+"_"+dist+"m__.geojson","w")
    _arc.write('{"type": "FeatureCollection","name": "red_vial_generalizada","crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:EPSG::4326" } },"features": [null')
    for _w in set(map(lambda _r:",\n"+json.dumps(_r),_dat['line'])):
        _arc.write(_w)
    _arc.write("\n]}")
    _arc.close()
    iSck._envClient(_gJson+"_"+dist+"m__.geojson",_cli)
    print("[info]  Tiempo Total de Generalizacion: %.10f seg." % (time()-_tm))
    _cli.close()