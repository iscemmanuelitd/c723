from django.apps import AppConfig


class DiccConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "dicc"


