
from clases import Convertir
import pathlib as ph
from arcpy.da import SearchCursor as sc
from arcpy import env as e

a = [sc,e]
ws = "%s\\datos\\puertos.gdb\\" % str(ph.Path.cwd())
a[1].workspace = ws
a[1].overwriteOutput
schema = {'geometry':'LineString','properties': {'id': 'int','principal':'bool'}}
for row in a[0](ws+"poligon",["OID@","SHAPE@JSON"]):
    pp="newDatos/poli_%s.shp"%row[0]
    from fiona import open as abrir
    with abrir(pp,'w','ESRI Shapefile',schema,crs="EPSG:4326") as c:
        c.write({'geometry':row[1],'properties': {'id': row[0],'principal':True}})
        c.close()
        _dat_ =  Convertir(pp,1)
        lineas = _dat_.Skeletor(pp)
        print(lineas,end="\n"*5)


#"%py3Pro%" separaObjetos.py