# -*- coding: cp1252 -*-
from pymongo import MongoClient
from time import time
from datetime import datetime as dt
import sys
import shutil
from datosIE import datos as _d
import random
import os

class GeneralizacionPuntos:
	def __init__(self,d,_idE):
		self._dat,self.db,self._tI,self._grupo,self._hijos,self.logs = d,None,[time()],0,[],open("src/_tmp_%s.log" % _idE,"w")
		self._hTmp,self.porc,self._usu,self.coll,self._idE = [],self._arr(15),"",dt.now().strftime("%d%m%Y-%H%M%S_")+_idE,_idE
	def _cnx(c):
		conn = MongoClient(c._dat[0],c._dat[1])
		c.db = conn.generalizacion
		[c.db[co].drop() for co in c.db.list_collection_names() if co[16:]==c._idE]
		c.db.create_collection(c.coll)
	def _g(c):
		c._grupo += 1
		return c._grupo
	def _arr(a,_n):
		_aP=[round(random.triangular(5,100,5),1) for i in range(_n)]
		_aP.append(100.0)
		return _aP
	def _proceso(s,_msg,_ok=True,_p=0):
		if _ok:
			s.logs.write(_msg)
			s.logs.close()
			shutil.copyfile("src/_tmp_%s.log" % s._idE,"src/_proceso_%s.log" % s._idE)
			s.logs = open("src/_tmp_%s.log" % s._idE,"a")
			return _p
		return 0
	def _faltantes(_f,_dis):
		lista = []
		for f in _f.db[_f.coll].find({"properties.visible":False}):	
			ban=True
			for c in f['cercanos']:
				if c['dist']<_dis:			
					if _f.db[_f.coll].find_one({"_id":c['id_c'],"properties.visible":True})!=None:
						ban=False
			if ban:	
				lista.append(f['_id'])
		_f.db[_f.coll].update_many({"_id":{"$in":lista}},{"$set":{"properties.visible":True}})
		
_arg = sys.argv
_gen = GeneralizacionPuntos(["localhost",27017],_arg[4])
_gen._cnx()
_dat = _d(_gen.db)
_gen._proceso("[info]  Escribiendo datos en MongoDB... <span style='color:rgb(10,150,30)'>")
_gen._tI.append(time())
_tot,_gen.porc = _dat.importar(_arg[3],_gen)
_gen._tI[1]-=time()
_gen._proceso("[info]  Tiempo empleado: %.5f seg. <br>" % (-1*_gen._tI[1]))

_gen._proceso("[info]  %d Datos escritos correctamente.<br>" % _tot)
_gen._proceso("[info]  Buscando elementos cercanos... <span style='color:rgb(10,150,30)'>")
_gen._tI.append(time())
_gen.db[_gen.coll].update_many({"properties.hierarchy_field":0},{"$set":{"properties.visible":True}})
for r in _gen.db[_gen.coll].find():    
	_near = list(_gen.db[_gen.coll].aggregate([{"$geoNear": {"near": { "type": "Point", "coordinates":r["geometry"]["coordinates"]},"distanceField": "distancia","maxDistance":int(_arg[1])*2,"spherical":True}}]))
	_set = {"$set":{"properties.visible":True}} if len(_near)==1 else {"$set":{"cercanos":[{"id_c":x["_id"],"dist":x["distancia"],"prioridad":x["properties"]["hierarchy_field"],"hab":x["properties"]["NUM_HAB"],"capa":x["properties"]["CAPA"]} for x in _near if r["_id"]!=x["_id"]],"properties.grupo":0}}
	_gen.db[_gen.coll].update_many({"_id":r["_id"]},_set)
	_perc = round((float(r["_id"])/float(_tot))*100.0,1)
	if _gen._proceso(str(_perc)+"% , ",True if _perc in _gen.porc else False,_perc)>0:
		_gen.porc.remove(_perc)
_gen.logs.seek(-2,os.SEEK_END)
_gen._proceso("</span><br>")
_gen._tI[2]-=time()
_gen._proceso("[info]  Tiempo empleado: %.5f seg. <br>" % (-1*_gen._tI[2]))

_gen._tI.append(time())
_gen._proceso("[info]  Agrupando elementos en base al buffer dado... <br>")
with _gen.db[_gen.coll].find({"properties.visible":{"$exists":False}}) as _cur:
	def _visIni(_v,_i,_obj):
		_newV = [_o for _o in _obj if _o["id_c"] in [_new["_id"] for _new in _gen.db[_gen.coll].find({"$and":[{"_id":{"$in":_v}},{"$or":[{"properties.visible":{"$exists":False}},{"properties.visible":True}]}]})] ]
		_v.append(_i)
		_gen.db[_gen.coll].update_many({"_id":{"$in":_v},"properties.visible":{"$exists":False}},{"$set":{"properties.visible":False}})
		return _newV
	for _res in _cur:
		_i = _res["_id"]
		if not _i in _gen._hijos:
			_gr=_gen._g()
			_gen._hTmp=[_i]
			for _ii in _gen._hTmp:
				_gen._hijos.append(_ii)
				for x in [_e["id_c"] for _e in list(_gen.db[_gen.coll].find({"_id":_ii}))[0]["cercanos"] if (not _e["id_c"] in _gen._hTmp)]:   #and _e["prioridad"]>0)]:
					_gen._hTmp.append(x)
			_gen.db[_gen.coll].update_many({"_id":{"$in":_gen._hTmp}},{"$set":{"properties.grupo":_gr}})

_gen._tI[3]-=time()
_gen._proceso("[info]  Tiempo empleado: %.5f seg. <br>" % (-1*_gen._tI[3]))


_gen._tI.append(time())
_gen.porc = _gen._arr(15)			
_gen._proceso("[info]  Discriminando elementos que NO serán visibles... <span style='color:rgb(10,150,30)'>")	
for _g in xrange(1,_gen._grupo+1):
	with _gen.db[_gen.coll].find({"properties.grupo":_g,"cercanos.dist":{"$lt":float(_arg[2])}}) as _cur:
		_res = list(_cur)
		for _i in range(len(_res)):
			if not _res[_i]["properties"].has_key("visible"):
				_res[_i]["properties"]["visible"]=False				
				_vCer = [c for c in _res[_i]["cercanos"] if c["dist"]<=float(_arg[2])]
				_vIdC = [ic["id_c"] for ic in _vCer]
				for _ii in _vIdC:
					for _x in range(len(_res)):
						if _res[_x]["_id"]==_ii:
							_res[_x]["properties"]["visible"]=False
							break
				_vCer=_visIni(_vIdC,_res[_i]["_id"],_vCer)
				_vCer.sort(key=lambda x:x["prioridad"])
				_win = _loss = _res[_i]["_id"]
				for _w in _vCer:
					if _w["prioridad"]==_res[_i]["properties"]["hierarchy_field"]:
						if _w["capa"]=="LOCALIDAD" and _res[_i]["properties"]["CAPA"]=="LOCALIDAD":
							if int(_w["hab"]) >  int(_res[_i]["properties"]["NUM_HAB"]):
								_win = _w["id_c"]
							else:
								_loss = _w["id_c"]
						else:
							_loss = _w["id_c"]
					elif _w["prioridad"]<_res[_i]["properties"]["hierarchy_field"]:
						_win = _w["id_c"]
					else:
						_loss = _w["id_c"]
					_gen.db[_gen.coll].update_one({"_id":_win},{"$set":{"properties.visible":True}})
					_gen.db[_gen.coll].update_one({"_id":_loss},{"$set":{"properties.visible":False}})
					if _win == _w["id_c"]:
						break
				_porc = round((float(_g)/float(_gen._grupo))*100.0,1)
				if _gen._proceso(str(_porc)+"% , ",True if _porc in _gen.porc else False,_porc)>0:
					_gen.porc.remove(_porc)					
_gen.logs.seek(-2,os.SEEK_END)
_gen._proceso("</span><br>")
_gen._tI[4]-=time()
_gen._proceso("[info]  Tiempo empleado: %.5f seg. <br>" % (-1*_gen._tI[4]))
_gen._proceso("[info]  Obteniendo elementos visibles... <br>")
_gen.db[_gen.coll].update_many({"properties.visible":{"$exists":False}},{"$set":{"properties.visible":True}})
_gen._faltantes(float(_arg[2]))
_gen._proceso("[info]  Generando archivo de salida... <span style='color:rgb(10,150,30)'>")
_gen.porc = _gen._arr(15)
_dat.exportar(_arg[3],_gen)
_gen._proceso("[info]  Total Elementos: %d ---- Elementos Reducidos: %d ---- Porcentaje de Generalización: %.3f %s<br>" % tuple(_dat.resumen(_gen)))
_gen._tI[0]-=time()
_gen._proceso("[info]  Tiempo Total de Generalizacion: %.5f seg." % (-1*_gen._tI[0]))	
_gen.logs.close()
print ("tiempos",2,_gen._tI,"valores",2,_dat.resumen(_gen),"extent",2,_dat._extend(_gen))
