
pt = arcpy.Point(-12683890.6, 5811151.5)
pt_geometry = arcpy.PointGeometry(pt, spatial_reference=3857)

pt_geometry.angleAndDistanceTo(other_geometry=)