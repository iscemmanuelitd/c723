import pyautogui
import time

while True:
    x =  time.ctime().replace(":","_")
    print(x)
    myScreenshot = pyautogui.screenshot()
    myScreenshot.save('%s.jpg' % x)
    time.sleep(5)
    